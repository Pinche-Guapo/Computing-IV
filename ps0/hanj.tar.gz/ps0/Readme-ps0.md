# PS0: Hello SFML

## Contact
Name: Jeongjae Han
Section: 051
Time to Complete: 5 hours


## Description
Explain what the project is supposed to do

The project is to use Ubuntu to get used to Linux OS and also, get the sense of SFML.

### Features
Describe what your major decisions were and why you did things that way.

I wanted to make it flip with a one button, but I could not figure out the way.
Therefore, I put them into two different buttons.

I made the sprite move 10 for the side way and 5 for the up and down, so the movements are visible. 

### Issues
What doesn't work.  Be honest.  You might be penalized if you claim something works and it doesn't.

It does not cause any error when I click buttons to interact with a sprite.

### Extra Credit
Anything special you did.  This is required to earn bonus points.

My program can move, flip and rotate the sprite!
Also when it reaches to the limit, instead of stopping from there, it moves to the opposite wall and keeps moving

## Integrity
Read the University policy Academic Integrity, and answer the following question:

There are six examples of academic misconduct, labeled (a) through (f). Other than (a), "Seeks to claim credit for the work or efforts of another without authorization or citation," which of these do you think would most apply to this class, and why? Write approx. 100-200 words. Note: there is no single correct answer to this. I am looking for your opinion.

Plagerism is bad, but reference is good as long as the person learns from it and knows how to use it in his language. On the school website, there is lists of the plagiarism that cause the inequality in grading. My opinion of programming, there is a lot of sources we can use and copy from, but as I said as long as we are learning from it instead of just using it, it should be fine. Also, in the field of Computer Science, all the people are getting the codes on the internet anyway, so we should learn how to interpret with the codes well those are online properly. However, the fact that there are student just pay for chegg and submit the homework and get 100% on it. In my opinion, it is unfair because they are paying money instead of studying for the material for an easier way. also, risking their grade and career, later on, by copying work. In addition to that, they are not going to learn anything due to lack of their progress. In the worst case, they are not going to become a computer scientist. Beside that other dishonesty and misconduct that listed on the website,  the students and the professors try their best to find out and make the grading system fair even though it is hard. 


## Acknowledgements
List all sources of help including the instructor or TAs, classmates, and web pages.

Youtube.com
sfml0-def.org

### Credits
List where you got any images or other resources.
sprite.com
